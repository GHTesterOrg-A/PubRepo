dir_name=$1
rm -rf ${dir_name}
mkdir -p ${dir_name}
cd ${dir_name}
rm -rf *
branch=ICG_v10_0_0_Main_Branch
dplanbranch=UserStack_v10_0_0_Main_Branch
git clone git@git-biz.qianxin-inc.cn:icg/ICG-dp-devel.git ICG-dp-devel
cd ICG-dp-devel
git checkout -b $branch remotes/origin/${dplanbranch}
cd ..

mkdir $branch
cd $branch
git checkout -b $branch remotes/origin/${branch}
git clone git@git-biz.qianxin-inc.cn:icg/interface.git interface
cd interface
git checkout -b $branch remotes/origin/${branch}
cd ..

git clone git@git-biz.qianxin-inc.cn:icg/audit.git ns_audit
cd ns_audit
git checkout -b $branch remotes/origin/${branch}
cd ..

